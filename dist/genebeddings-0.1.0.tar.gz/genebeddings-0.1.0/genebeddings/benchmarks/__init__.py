"""Genebeddings benchmark utilities."""
